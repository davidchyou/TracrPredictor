require "rnahybrid_module.pm";

sub svm_predict {
	my ($dir) = @_;
	
	open(RAWDAT, "$dir/genome_tracr_summary.csv");
	my @contents = <RAWDAT>;
	close(RAWDAT);
	
	if (-e "$dir/svm_dat_in.csv") {
		unlink("$dir/svm_dat_in.csv");
	}
	
	if (-e "$dir/svm_out.csv") {
		unlink("$dir/svm_out.csv");
	}
	
	if (-e "$dir/genome_tracr_summary_classified.csv") {
		unlink("$dir/genome_tracr_summary_classified.csv");
	}
	
	open(SVMIN, ">>$dir/svm_dat_in.csv");
	for (my $i = 0; $i < scalar(@contents); $i++) {
		if ($i == 0) {
			next;
		}
		
		my $line = @contents[$i];
		$line =~ s/\n//g;
	
		my @toks = split(/\,/, $line);
		
		my $mfe = @toks[15];	
		my $dbstr = @toks[17];
		my @parts = split('&', $dbstr);
		
		#my @rs1 = ar_basepair_stats($dbstr, 0);
		#my @rs2 = ar_basepair_stats($dbstr, 1);
	
		my $mfe_n = $mfe / (length($parts[1]));
		
		my $dist = @toks[34];
		my $br = @toks[37];
		my $bt = @toks[38];
		my $clen = @toks[28];
		my $pdist = $dist / $clen;
		
		my $rep_part = @parts[0];
		$rep_part =~ s/^\.+//g;
		$rep_part =~ s/\.+$//g;
		
		my $ar_part = @parts[1];
		$ar_part =~ s/^\.+//g;
		$ar_part =~ s/\.+$//g;
	
		my $mhl = max_hybrid_helix_length($dbstr);
		my $nmih = num_mismatches_in_hybrid($dbstr);
		my $qnmih = $nmih / (length($rep_part) + length($ar_part));
		
		#my @dat = ($mfe_n, @rs2[0], $pdist, $br, $bt);
		my @dat = ($mfe_n, log($dist), $br, $bt, $qnmih, $mhl);
		
		my $class = 1;
		my $str = $class;
		$str .= " ";
	
		for (my $j = 0; $j < scalar(@dat); $j++) {
			my $ind = $j + 1;
			$str .= "$ind:" . @dat[$j] . " ";
		}
		$str .= "\n";
		print SVMIN $str;
	}
	close(SVMIN);
	
	$flag = system("svm-predict -b 1 -q $dir/svm_dat_in.csv svm_dat.csv.model $dir/svm_out.csv");
	
	open(SVMOUT, "$dir/svm_out.csv");
	my @content_svm = <SVMOUT>;
	close(SVMOUT);
	
	open(CLASS, ">>$dir/genome_tracr_summary_classified.csv");
	for (my $i = 0; $i < scalar(@content_svm); $i++) {
		my $line1 = @contents[$i];
		my $line2 = @content_svm[$i];
		$line1 =~ s/\n//g;
		$line2 =~ s/\n//g;
		
		my @toks = split(' ', $line2);
		
		if ($i == 0) {
			my $str = $line1 . ",PR_POS,PR_NEG\n";
			print CLASS $str;
		} else {
			my $p1 = @toks[1];
			my $p2 = @toks[2];
			my $str = $line1 . ",$p1,$p2\n";
			print CLASS $str;
		}
	}
	close(CLASS);
	
	return $flag;
}

return 1;