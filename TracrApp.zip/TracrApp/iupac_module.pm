sub match_symbol {
	my ($iupac, $query) = @_;
	
	my $str = "ACGT";
	my $cmd = "grep $iupac iupac.csv";
	my @results = `$cmd`;
	
	if (scalar(@results) == 0) {
		return 0;
	}
	
	my $line = @results[0];
	$line =~ s/\n//g;
	
	my @toks = split(/\,/, $line);
	my $ind = index($str, $query);
	
	if ($ind < 0) {
		return 0;
	}
	
	my $b = @toks[$ind + 1];
	return $b;
}

sub iupac_match_seq_start {
	my ($iupac_seq, $query_seq) = @_;
	
	my $len = length($iupac_seq);
	if (length($query_seq) < $len) {
		$len = length($query_seq);
	}
	
	my @tk1 = split('', $iupac_seq);
	my @tk2 = split('', $query_seq);
	
	my $b = 0;
	for (my $i = 0; $i < $len; $i++) {
		if ($i == 0) {
			$b = match_symbol(@tk1[$i], @tk2[$i]);
		} else {
			$b *= match_symbol(@tk1[$i], @tk2[$i]);
		}
	}
	return $b;
}

return 1;