my $pat = @ARGV[0];
my $seq_in = @ARGV[1];
my $seq_out = @ARGV[2];

my $cmd = "scan_for_matches $pat < $seq_in > $seq_out";
my $flag = system($cmd);