sub parse_rnafold_output {
	my ($str) = @_;
	my $path = $str;
	my @fold_data = ();
	
	open(seqs, $path) or die "can't open txt file";
	
	while (<seqs>) {
		my $line = $_;
		$line =~s/\n//g;
		if (is_nucl($line)) {
			next;
		} else {
			my @rec = split(/\s/, $line);
			if (is_dot_bracket(@rec[0])) {
				my $rest = '';
				for (my $i = 1; $i < scalar(@rec); $i++) {
					$rest .= @rec[$i]
				}
				my $num_part = $rest;
				my $temp = ($num_part =~ /\s*(-*\d+[\.]*[\d]*)/);
				my $mfe = $1;
				push(@fold_data, @rec[0]);
				push(@fold_data, $mfe);
				last;
			} elsif (@rec[0] =~ />/) {
				next;
			} else {
				last;
			}
		}
	}
	
	close(seqs);
	
	return @fold_data;
}

sub parse_rnacofold_output {
	my ($str) = @_;
	my $path = $str;
	my @fold_data = ();
	
	open(seqs, $path) or die "can't open txt file";
	
	while (<seqs>) {
		my $line = $_;
		$line =~s/\n//g;
		if (is_nucl_cf($line)) {
			next;
		} else {
			my @rec = split(/\s/, $line);
			if (is_dot_bracket_cf(@rec[0])) {
				my $rest = '';
				for (my $i = 1; $i < scalar(@rec); $i++) {
					$rest .= @rec[$i]
				}
				my $num_part = $rest;
				my $temp = ($num_part =~ /\s*(-*\d+[\.]*[\d]*)/);
				my $mfe = $1;
				push(@fold_data, @rec[0]);
				push(@fold_data, $mfe);
				last;
			} elsif (@rec[0] =~ />/) {
				next;
			} else {
				last;
			}
		}
	}
	
	close(seqs);
	
	return @fold_data;
}

sub is_nucl {
	($str_in) = @_;
	my $str = $str_in;
	my $cnt = ($str =~ tr/AUCG//);
	my $len = length($str);
	my $diff = $cnt - $len;
	return ($diff == 0 && $len > 0);
}

sub is_dot_bracket {
	($str_in) = @_;
	my $str = $str_in;
	my $cnt = ($str =~ tr/\.\(\{\[\|\,\)\}\]<>//);
	my $cnt_left_bk =~ tr/\(\{\[<//;
	my $cnt_right_bk =~ tr/\)\}\]>//;
	my $len = length($str);
	my $diff1 = $cnt - $len;
	my $diff2 = $cnt_left_bk - $cnt_right_bk;
	return ($diff1 == 0 && $len > 0 && diff2 == 0);
}

sub is_nucl_cf {
	($str_in) = @_;
	my $str = $str_in;
	my $cnt = ($str =~ tr/AUCG&//);
	my $len = length($str);
	my $diff = $cnt - $len;
	return ($diff == 0 && $len > 0);
}

sub is_dot_bracket_cf {
	($str_in) = @_;
	my $str = $str_in;
	my $cnt = ($str =~ tr/\.\(\{\[\|\,\)\}\]<>&//);
	my $cnt_left_bk =~ tr/\(\{\[<//;
	my $cnt_right_bk =~ tr/\)\}\]>//;
	my $len = length($str);
	my $diff1 = $cnt - $len;
	my $diff2 = $cnt_left_bk - $cnt_right_bk;
	return ($diff1 == 0 && $len > 0 && diff2 == 0);
}

sub parse_dbstr {
	my ($str) = @_;
	
	my @chars = split('', $str);
	
	my $br_count = 0;
	my $d_count = 0;
	my $hc_count = 0;
	my @br_count_list = ();
	my @str_list = ();
	my @h_list = ();
	my @c_list = ();
	my @l_list = ();
	for (my $i = 0; $i < scalar(@chars); $i++) {
		my $ch = @chars[$i];
		if ($ch =~ /\./) {
			if ($i == 0 || $br_count == 0) {
				$d_count++;
			}
		}
		
		if ($ch =~ /\(/) {
			#$br_count = $br_count + 1;
			push(@br_count_list, $br_count++);
			if ($d_count > 0) {
				push(@str_list, 'L' . $d_count);
				push(@l_list, $d_count);
				$d_count = 0
			}
		}
		
		if ($ch =~ /\)/) {
			#$br_count = $br_count - 1;
			push(@br_count_list, $br_count--);
		}
		
		if ($br_count == 0) {
			if (scalar(@br_count_list) > 0) {
				$hc_count++;
				my $c = disc_fcn(@br_count_list);
				if ($c == 1) {
					push(@str_list, 'H' . $hc_count);
					push(@h_list, $hc_count);
				} else {
					push(@str_list, 'C' . $hc_count);
					push(@c_list, $hc_count);
				}
				@br_count_list = ();
				$hc_count = 0;
			}
		} else {
			$hc_count++;
		}
		
		if ($i == scalar(@chars) - 1) {
			if ($d_count > 0) {
				push(@str_list, 'L' . $d_count);
				push(@l_list, $d_count);
				$d_count = 0
			}
		}
	}
	
	my $out = '';
	for (my $i = 0; $i < scalar(@str_list); $i++) {
		if ($i == scalar(@str_list) - 1) {
			$out .= @str_list[$i];
		} else {
			$out .= (@str_list[$i] . '-');
		}
	}
	
	my @max_min_h = max_min(@h_list);
	my @max_min_c = max_min(@c_list);
	my @max_min_l = max_min(@l_list);
	
	my $nh = scalar(@h_list);
	my $nc = scalar(@c_list);
	my $nl = scalar(@l_list);
	
	my $first_h = 0;
	my $first_c = 0;
	my $first_l = 0;
	
	if ($nh > 0) {
		$first_h = @h_list[0];
	}
	
	if ($nc > 0) {
		$first_c = @c_list[0];
	}
	
	if ($nl > 0) {
		$first_l = @l_list[0];
	}

	$out .= "\," . $nh . "\," . @max_min_h[1] . "\," . @max_min_h[0] . "\," . $first_h .
	        "\," . $nc . "\," . @max_min_c[1] . "\," . @max_min_c[0] . "\," . $first_c .
	        "\," . $nl . "\," . @max_min_l[1] . "\," . @max_min_l[0] . "\," . $first_l;
	
	return $out;
}

sub disc_fcn {
	my @nums = @_;
	
	if (scalar(@nums) <= 1) {
		return 0;
	}
	
	if (scalar(@nums) == 2) {
		return 1; 
	}
	
	my $c = 0;
	for (my $i = 2; $i < scalar(@nums); $i++) {
		my $a2 = @nums[$i];
		my $a1 = @nums[$i - 1];
		my $a0 = @nums[$i - 2];
		
		if ($a1 > $a2 && $a1 > $a0) {
			$c++;
		}
	}
	return $c;
}

sub max_min {
	my @nums = @_;
	
	my $maxsofar = 0;
	my $minsofar = 0;
	
	if (scalar(@nums) > 0) {
		$maxsofar = @nums[0];
		$minsofar = @nums[0];
	}
	
	for (my $i = 0; $i < scalar(@nums); $i++) {
		if (@nums[$i] >= $maxsofar) {
			$maxsofar = @nums[$i];
		}
		
		if (@nums[$i] <= $minsofar) {
			$minsofar = @nums[$i];
		}
	} 
	
	my @out = ($maxsofar, $minsofar);
	return @out;
}

return 1;